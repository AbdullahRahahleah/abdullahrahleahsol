package rahahleah.rahahleah.Beans;
public class HotelPricingInfo {
	public String getAveragePriceValue() {
		return averagePriceValue;
	}
	public void setAveragePriceValue(String averagePriceValue) {
		this.averagePriceValue = averagePriceValue;
	}
	public String getTotalPriceValue() {
		return totalPriceValue;
	}
	public void setTotalPriceValue(String totalPriceValue) {
		this.totalPriceValue = totalPriceValue;
	}
	public String getOriginalPricePerNight() {
		return originalPricePerNight;
	}
	public void setOriginalPricePerNight(String originalPricePerNight) {
		this.originalPricePerNight = originalPricePerNight;
	}
	public String getHotelTotalBaseRate() {
		return hotelTotalBaseRate;
	}
	public void setHotelTotalBaseRate(String hotelTotalBaseRate) {
		this.hotelTotalBaseRate = hotelTotalBaseRate;
	}
	public String getHotelTotalTaxesAndFees() {
		return hotelTotalTaxesAndFees;
	}
	public void setHotelTotalTaxesAndFees(String hotelTotalTaxesAndFees) {
		this.hotelTotalTaxesAndFees = hotelTotalTaxesAndFees;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getHotelTotalMandatoryTaxesAndFees() {
		return hotelTotalMandatoryTaxesAndFees;
	}
	public void setHotelTotalMandatoryTaxesAndFees(String hotelTotalMandatoryTaxesAndFees) {
		this.hotelTotalMandatoryTaxesAndFees = hotelTotalMandatoryTaxesAndFees;
	}
	public String getPercentSavings() {
		return percentSavings;
	}
	public void setPercentSavings(String percentSavings) {
		this.percentSavings = percentSavings;
	}
	public String getDrr() {
		return drr;
	}
	public void setDrr(String drr) {
		this.drr = drr;
	}
	private String averagePriceValue;
	private String totalPriceValue;
	private String originalPricePerNight;
	private String hotelTotalBaseRate;
	private String hotelTotalTaxesAndFees;
	private String currency;
	private String hotelTotalMandatoryTaxesAndFees;
	private String percentSavings;
	private String drr;
}
